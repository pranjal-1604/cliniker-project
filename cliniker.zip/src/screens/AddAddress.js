import React, {useEffect, useState} from 'react';

import {
  Text,
  StyleSheet,
  Image,
  View,
  Dimensions,
  TouchableOpacity,
  FlatList,
  ImageBackground,
  ScrollView,
  SafeAreaView,
  TextInput,
  Modal,
} from 'react-native';
import links from '../components/links';
import colors from '../components/colors';
import firestore from '@react-native-firebase/firestore';
import AsyncStorage from '@react-native-community/async-storage';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');
import backIcon from '../assets/back-black.png';

export default function AddAddress({navigation, route}) {
  const {details} = route.params;
  const [user, setuser] = useState();
  const [address, setaddress] = useState({
    line1: details.type == 'edit' ? details.line1 : '',
    line2: details.type == 'edit' ? details.line2 : '',
    city: details.type == 'edit' ? details.city : '',
    pincode: details.type == 'edit' ? details.pincode : '',
    lan: details.type == 'edit' ? details.pincode : '',
    log: details.type == 'edit' ? details.pincode : '',
  });

  const submit = async () => {
    if (details.type == 'edit') {
      console.log('do edit for' + address);
    } else {
      console.log('do add for' + address);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    try {
      const value = await AsyncStorage.getItem('uid');
      if (value !== null) {
        // value previously
        console.log(value);
        setuser(value);
      }
    } catch (e) {
      // error reading value
    }
  };

  const onChange = (text, name) => {
    setaddress({...address, [name]: text});
  };

  return (
    <SafeAreaView style={styles.safeContainer}>
      <ScrollView style={styles.scrollView}>
        <View style={[styles.customHeader]}>
          <View style={[styles.headerLeft]}>
            <TouchableOpacity
              onPress={() => {
                navigation.goBack();
              }}>
              <Image source={backIcon} style={styles.headerIcon} />
            </TouchableOpacity>
            <Text style={[styles.font, styles.headerTitle]}>ADD ADDRESSES</Text>
            <Text></Text>
          </View>
        </View>
        <View style={styles.main}>
          <View style={styles.card}>
            <View>
              <TextInput
                value={address.line1}
                placeholder={'Address Line 1'}
                placeholderTextColor={'#979797'}
                onChangeText={text => onChange(text, 'line1')}
                style={styles.TextInput}
              />
            </View>
            <View>
              <TextInput
                value={address.line2}
                placeholder={'Address Line 2'}
                placeholderTextColor={'#979797'}
                onChangeText={text => onChange(text, 'line2')}
                style={styles.TextInput}
              />
            </View>
            <View>
              <TextInput
                value={address.city}
                placeholder={'City'}
                placeholderTextColor={'#979797'}
                onChangeText={text => onChange(text, 'city')}
                style={styles.TextInput}
              />
            </View>
            <View>
              <TextInput
                value={address.pincode}
                placeholder={'Pincode'}
                placeholderTextColor={'#979797'}
                onChangeText={text => onChange(text, 'pincode')}
                style={styles.TextInput}
              />
            </View>

            <View style={{marginTop: 20}}>
              <TouchableOpacity
                onPress={() => submit()}
                style={[styles.button, {backgroundColor: '#835CB9'}]}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text style={[styles.buttonT, {}]}>ADD ADDRESS</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  customHeader: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: SCREEN_WIDTH,
    height: 56,
    paddingHorizontal: 16,
    borderBottomRightRadius: 12,
    borderBottomLeftRadius: 12,
  },
  headerLeft: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerIcon: {
    width: 22,
    height: 22,
  },
  headerTitle: {
    color: '#373737',
    fontSize: 16,
    fontWeight: 'bold',
  },
  main: {
    width: SCREEN_WIDTH - 32,
    paddingVertical: 12,
    alignSelf: 'center',
    marginTop: 20,
  },
  spacebetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  card: {
    backgroundColor: colors.white,
    borderRadius: 6,
    elevation: 5,
    paddingVertical: 10,
    paddingHorizontal: 8,
    marginVertical: 10,
  },
  buttonT: {
    fontSize: 12,
    color: colors.white,
    textAlign: 'center',
    fontWeight: '900',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 6,
    height: 32,
    width: 115,
    alignSelf: 'center',
    marginTop: 10,
  },
  add: {
    color: '#979797',
    fontSize: 16,
    fontWeight: 'bold',
  },
  TextInput: {
    width: '100%',
    alignSelf: 'center',
    height: 40,
    marginTop: 12,
    borderBottomWidth: 1,
    paddingLeft: 10,
    fontSize: 16,
    borderColor: '#979797',
    color: '#979797',
  },
});
