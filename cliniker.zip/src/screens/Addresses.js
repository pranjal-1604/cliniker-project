import React, {useEffect, useState} from 'react';

import {
  Text,
  StyleSheet,
  Image,
  View,
  Dimensions,
  TouchableOpacity,
  FlatList,
  ImageBackground,
  ScrollView,
  SafeAreaView,
  TextInput,
  Modal,
} from 'react-native';
import links from '../components/links';
import colors from '../components/colors';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');
import backIcon from '../assets/back-black.png';

export default function Addresses({navigation, route}) {
  // const {addresses} = route.params;

  return (
    <SafeAreaView style={styles.safeContainer}>
      <ScrollView style={styles.scrollView}>
        <View style={[styles.customHeader]}>
          <View style={[styles.headerLeft]}>
            <TouchableOpacity
              onPress={() => {
                navigation.goBack();
              }}>
              <Image source={backIcon} style={styles.headerIcon} />
            </TouchableOpacity>
            <Text style={[styles.font, styles.headerTitle]}>MY ADDRESSES</Text>
            <Text></Text>
          </View>
        </View>
        <View style={styles.main}>
          <View style={styles.card}>
            <Text style={styles.add}>Address Line 1</Text>
            <Text style={styles.add}>Address Line 2</Text>
            <Text style={styles.add}>City</Text>
            <Text style={styles.add}>Pincode - 123456</Text>
            <View style={styles.spacebetween}>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('AddAddress', {
                    details: {
                      type: 'edit',
                      line1: 'near Primary',
                      line2: 'school',
                      city: 'nachangaon',
                      pincode: '123456',
                    },
                  })
                }
                style={[styles.button, {backgroundColor: '#835CB961'}]}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text style={[styles.buttonT, {color: '#373737'}]}>
                    EDIT ADDRESS
                  </Text>
                  <Image
                    style={{height: 20, marginLeft: 4, width: 20}}
                    source={links.arrow_grey}
                  />
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, {backgroundColor: '#835CB9'}]}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text style={[styles.buttonT, {}]}>SET AS ACTIVE</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate('AddAddress', {
                details: {
                  type: 'add',
                },
              })
            }
            style={[
              styles.button,
              {backgroundColor: '#835CB9', width: 140, marginVertical: 10},
            ]}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Image
                style={{height: 10, marginRight: 4, width: 10}}
                source={links.plus_yellow}
              />
              <Text style={[styles.buttonT, {}]}>ADD ADDRESS</Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  customHeader: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: SCREEN_WIDTH,
    height: 56,
    paddingHorizontal: 16,
    borderBottomRightRadius: 12,
    borderBottomLeftRadius: 12,
    elevation: 4,
  },
  headerLeft: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerIcon: {
    width: 22,
    height: 22,
  },
  headerTitle: {
    color: '#373737',
    fontSize: 16,
    fontWeight: 'bold',
  },
  main: {
    width: SCREEN_WIDTH - 32,
    paddingVertical: 12,
    alignSelf: 'center',
    marginTop: 20,
  },
  spacebetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  card: {
    backgroundColor: colors.white,
    borderRadius: 6,
    elevation: 5,
    paddingVertical: 10,
    paddingHorizontal: 8,
    marginVertical: 10,
    elevation: 4,
  },
  buttonT: {
    fontSize: 12,
    color: colors.white,
    textAlign: 'center',
    fontWeight: '900',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 6,
    height: 32,
    width: 115,
    alignSelf: 'center',
    marginTop: 10,
  },
  add: {
    color: '#373737',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
