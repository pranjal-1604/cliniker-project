import React, {useEffect, useState} from 'react';

import {
  Text,
  StyleSheet,
  Image,
  View,
  Dimensions,
  TouchableOpacity,
  FlatList,
  ImageBackground,
  ScrollView,
  SafeAreaView,
  TextInput,
  Animated,
} from 'react-native';
import links from '../components/links';
import colors from '../components/colors';

import {Rating} from '../components/ratings/index.tsx';
const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');
import backIcon from '../assets/back-black.png';

export default function Clinicdetails({navigation, route}) {
  const {details} = route.params;
  const doctors = [{key: 1}, {key: 2}, {key: 3}];
  const photos = [{key: 1}, {key: 2}, {key: 3}];
  const labs = [{key: 1}, {key: 2}];
  const [doctord, setdoctord] = useState(false);
  const scrollX = new Animated.Value(0);
  const [labd, setlabd] = useState(false);
  let position = Animated.divide(scrollX, SCREEN_WIDTH - 50);
  const [search, setsearch] = useState();

  useState(() => {
    console.log(details);
  }, []);
  return (
    <SafeAreaView style={styles.safeContainer}>
      <ScrollView style={styles.scrollView}>
        <View style={[styles.customHeader]}>
          <View style={[styles.headerLeft]}>
            <TouchableOpacity
              onPress={() => {
                navigation.goBack();
              }}>
              <Image source={backIcon} style={styles.headerIcon} />
            </TouchableOpacity>
            <Text style={[styles.font, styles.headerTitle]}>
              {details.name.toUpperCase()}
            </Text>
            <Text></Text>
          </View>
        </View>
        {/* <Image source={links.clinic} style={styles.clinicimg} /> */}
        <View
          style={{
            paddingTop: 10,
            alignContent: 'center',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View style={{height: 160, width: SCREEN_WIDTH - 50}}>
            <ScrollView
              horizontal={true}
              pagingEnabled={true}
              showsHorizontalScrollIndicator={false}
              onScroll={Animated.event(
                [{nativeEvent: {contentOffset: {x: scrollX}}}],
                {
                  useNativeDriver: false,
                },
              )}
              scrollEventThrottle={16}>
              {photos.map((source, i) => {
                return (
                  <TouchableOpacity key={source.photoKey} activeOpacity={0.7}>
                    <Image
                      key={i}
                      style={styles.clinicimg}
                      // resizeMode={'cover'}
                      source={links.clinic}
                    />
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>
          <View style={{flexDirection: 'row'}}>
            {photos.map((_, i) => {
              let opacity = position.interpolate({
                inputRange: [i - 1, i, i + 1],
                outputRange: [0.3, 1, 0.3],
                // inputRange: [i - 0.50000000001, i - 0.5, i, i + 0.5, i + 0.50000000001], // only when position is ever so slightly more than +/- 0.5 of a dot's index
                // outputRange: [0.3, 1, 1, 1, 0.3], // is when the opacity changes from 1 to 0.3
                extrapolate: 'clamp',
              });
              return (
                <Animated.View
                  key={i}
                  style={{
                    opacity,
                    height: 10,
                    width: 10,
                    backgroundColor: '#595959',
                    margin: 8,
                    borderRadius: 5,
                  }}
                />
              );
            })}
          </View>
        </View>
        <View style={styles.main}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image source={links.loc} style={styles.locimg} />
            <Text style={styles.name}>{details.location.place}</Text>
          </View>
          <Text style={[styles.speciality, {marginTop: 7, marginLeft: 16}]}>
            {details.facility.map(source => {
              return source + ', ';
            })}
          </Text>
          <View style={{marginTop: 15}}>
            <TouchableOpacity
              onPress={() => {
                setdoctord(!doctord);
              }}
              style={styles.spacebetween}>
              <Text style={styles.headerTitle}>Doctor Consultation</Text>

              <Image
                source={doctord == true ? links.arrow_up : links.arrow_down}
                style={styles.arr}
              />
            </TouchableOpacity>
            {doctord == true ? (
              <View>
                {doctors.map((source, index) => {
                  return (
                    <View key={index} style={styles.card}>
                      <View style={styles.spacebetween}>
                        <View>
                          <Text style={styles.name}>Dr. Anil Rastogi</Text>
                          <Text style={styles.speciality}>Cardiologists</Text>
                        </View>
                        <View style={{}}>
                          <Rating
                            showRating={false}
                            startingValue={4}
                            ratingCount={5}
                            readonly
                            imageSize={12}
                            style={{backgroundColor: colors.bg}}
                          />
                        </View>
                      </View>
                      <View
                        style={[
                          styles.spacebetween,
                          {marginTop: 13, alignItems: 'flex-start'},
                        ]}>
                        <View style={{width: '50%'}}>
                          <Text style={styles.name}>Area of Expertise</Text>
                          <Text style={styles.speciality}>
                            Infant Care, New Born Child Growth Child care
                            treatment
                          </Text>
                        </View>
                        <View
                          style={{
                            width: '50%',
                            alignItems: 'flex-end',
                          }}>
                          <View style={{alignItems: 'flex-start'}}>
                            <Text style={styles.time}>
                              Timing - 7:00am-9:00am
                            </Text>
                            <Text style={styles.time}>
                              Days - Mon, Tue, Wed
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={[styles.spacebetween, {marginTop: 13}]}>
                        <Text style={styles.name}>
                          Consultation Fee -{' '}
                          <Text style={{color: colors.purple}}>300</Text>
                        </Text>
                        <TouchableOpacity style={styles.button}>
                          <Text style={styles.buttonT}>BOOK APPOINTMENT</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  );
                })}
              </View>
            ) : null}
            <TouchableOpacity
              onPress={() => {
                setlabd(!labd);
              }}
              style={[
                styles.spacebetween,
                {marginTop: 15, borderTopWidth: 1, paddingTop: 10},
              ]}>
              <Text style={styles.headerTitle}>Lab Consultation</Text>

              <Image
                source={labd == true ? links.arrow_up : links.arrow_down}
                style={styles.arr}
              />
            </TouchableOpacity>
            {labd == true ? (
              <View>
                <View>
                  <TextInput
                    placeholder="Search"
                    onChangeText={text => setsearch(text)}
                    value={search}
                    style={styles.textinput}
                  />
                  <Image source={links.search} style={styles.search} />
                </View>
                {labs.map((source, index) => {
                  return (
                    <View>
                      <View style={styles.card}>
                        <View style={styles.spacebetween}>
                          <View>
                            <Text style={styles.name}>Liver Panel</Text>
                            <Text style={styles.speciality}>Package Name</Text>
                          </View>
                          <View style={{}}>
                            <Rating
                              showRating={false}
                              startingValue={4}
                              ratingCount={5}
                              readonly
                              imageSize={12}
                              style={{backgroundColor: colors.bg}}
                            />
                          </View>
                        </View>
                        <View
                          style={[
                            styles.spacebetween,
                            {marginTop: 13, alignItems: 'flex-start'},
                          ]}>
                          <View style={{width: '50%'}}>
                            <Text style={styles.name}>Facilities</Text>
                            <Text style={styles.speciality}>
                              Doctor Consultation , Lab Test
                            </Text>
                          </View>
                          <View
                            style={{
                              width: '50%',
                              alignItems: 'flex-end',
                            }}>
                            <View style={{alignItems: 'flex-start'}}>
                              <Text style={styles.time}>
                                Report in - 5 Hours
                              </Text>
                            </View>
                          </View>
                        </View>
                        <View style={[styles.spacebetween, {marginTop: 13}]}>
                          <Text style={styles.name}>
                            Consultation Fee -{' '}
                            <Text style={{color: colors.purple}}>300</Text>
                          </Text>
                          <TouchableOpacity style={styles.button}>
                            <Text style={styles.buttonT}>BOOK APPOINTMENT</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  );
                })}
              </View>
            ) : null}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  customHeader: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: SCREEN_WIDTH,
    height: 56,
    paddingHorizontal: 16,
    borderBottomRightRadius: 12,
    borderBottomLeftRadius: 12,
    elevation: 4,
  },
  headerLeft: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerIcon: {
    width: 22,
    height: 22,
  },
  headerTitle: {
    color: '#373737',
    fontSize: 16,
    fontWeight: 'bold',
  },
  main: {
    width: SCREEN_WIDTH - 32,
    paddingVertical: 12,
    alignSelf: 'center',
  },
  clinicimg: {
    width: SCREEN_WIDTH - 50,
    height: 150,
    alignSelf: 'center',
    borderRadius: 12,
    marginTop: 10,
  },
  name: {
    color: '#373737',
    fontSize: 12,
    fontWeight: 'bold',
  },
  speciality: {
    color: '#646464',
    fontSize: 12,
  },
  time: {
    color: '#373737',
    fontSize: 12,
    fontWeight: 'bold',
  },
  subT: {
    color: '#646464',
    fontSize: 11,
    fontWeight: 'bold',
  },
  locimg: {
    width: 7,
    height: 10,
    marginRight: 8,
  },
  spacebetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  arr: {
    height: 20,
    width: 20,
  },
  card: {
    backgroundColor: colors.white,
    borderRadius: 6,
    elevation: 5,
    paddingVertical: 10,
    paddingHorizontal: 8,
    marginVertical: 10,
    elevation: 4,
  },
  buttonT: {
    fontSize: 10,
    color: colors.white,
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.purple,
    borderRadius: 6,
    height: 30,
    width: 130,
    elevation: 6,
  },
  textinput: {
    width: '100%',
    backgroundColor: colors.white,
    borderRadius: 6,
    alignSelf: 'center',
    height: 50,
    marginTop: 12,
    paddingLeft: 70,
    elevation: 4,
    color: colors.black,
  },
  search: {
    height: 30,
    width: 30,
    position: 'absolute',
    left: 20,
    top: 20,
    elevation: 5,
  },
});
