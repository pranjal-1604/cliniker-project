export default {
  purple: '#835CB9',
  dark: '#7549B1',
  primary: '#3A3238',
  text: '#F8F0FB',
  black: '#000',
  white: '#fff',
  bg: '#F9F9FF',
  grey: '#00000069',
  yell: '#FFDE70',
};
