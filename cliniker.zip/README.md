# cliniker
npm i

npx react-native run-android
