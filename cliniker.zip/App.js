/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */
import Index from './src//Index';
import React from 'react';

const App = () => {
  return <Index />;
};
export default App;
